from pathlib import Path
import pandas as pd
import yfinance as yf

def download_ohlcv(ticker="SPY", start="2015-01-01", end=None, output_dir="data"):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    df = yf.download(ticker, start=start, end=end, interval="1d",
                     auto_adjust=True, progress=False)
    if df.empty:
        raise ValueError("No data returned; check ticker, dates, or connection.")
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    cols = ["Open", "High", "Low", "Close", "Volume"]
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    df = df[cols].copy().sort_index()
    df = df[~df.index.duplicated(keep="last")].dropna()
    if len(df) < 300:
        raise ValueError(f"Only {len(df)} rows; at least 300 are required.")
    df.to_csv(out / f"{ticker.lower()}_daily.csv")
    return df
