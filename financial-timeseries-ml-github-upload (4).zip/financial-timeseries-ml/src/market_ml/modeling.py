import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.model_selection import TimeSeriesSplit, cross_val_score
from sklearn.pipeline import Pipeline

def build_model():
    return Pipeline([
        ("imputer", SimpleImputer(strategy="median")),
        ("model", RandomForestRegressor(n_estimators=250, max_depth=5,
          min_samples_leaf=10, random_state=42, n_jobs=-1))
    ])

def evaluate_model(train, test, feature_columns):
    X_train, y_train = train[feature_columns], train["target_next_return"]
    X_test, y_test = test[feature_columns], test["target_next_return"]
    cv = TimeSeriesSplit(n_splits=5)
    model = build_model()
    scores = cross_val_score(model, X_train, y_train, cv=cv,
                             scoring="neg_mean_absolute_error")
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    baseline = np.zeros(len(y_test))
    out = pd.DataFrame({"actual_next_return": y_test,
                        "predicted_next_return": pred,
                        "baseline_prediction": baseline}, index=test.index)
    metrics = {
        "test_rows": int(len(test)),
        "mae": float(mean_absolute_error(y_test, pred)),
        "rmse": float(np.sqrt(mean_squared_error(y_test, pred))),
        "zero_return_baseline_mae": float(mean_absolute_error(y_test, baseline)),
        "directional_accuracy": float(np.mean(np.sign(pred) == np.sign(y_test))),
        "walk_forward_cv_mean_mae": float(-scores.mean()),
        "walk_forward_cv_std_mae": float(scores.std())
    }
    return metrics, out

def simulate_long_only_strategy(predictions, one_way_cost_bps=5.0):
    out = predictions.copy()
    position = (out["predicted_next_return"] > 0).astype(float)
    turnover = position.diff().abs()
    if len(turnover):
        turnover.iloc[0] = abs(position.iloc[0])
    out["position"] = position
    out["gross_strategy_return"] = position * out["actual_next_return"]
    out["transaction_cost"] = turnover * (one_way_cost_bps / 10000)
    out["net_strategy_return"] = out["gross_strategy_return"] - out["transaction_cost"]
    out["equity_curve"] = (1 + out["net_strategy_return"]).cumprod()
    metrics = {
        "one_way_transaction_cost_bps": float(one_way_cost_bps),
        "strategy_total_return": float(out["equity_curve"].iloc[-1] - 1),
        "buy_and_hold_total_return": float((1 + out["actual_next_return"]).prod() - 1),
        "number_of_position_changes": int((turnover > 0).sum())
    }
    return metrics, out
