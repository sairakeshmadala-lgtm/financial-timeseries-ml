import pandas as pd

FEATURE_COLUMNS = ["return_1d", "return_5d", "return_10d", "ma_ratio_5",
                   "ma_ratio_20", "volatility_10d", "volatility_20d",
                   "volume_change", "range_pct"]

def make_features(prices):
    required = {"High", "Low", "Close", "Volume"}
    missing = required.difference(prices.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    data = prices.copy().sort_index()
    close = data["Close"].astype(float)
    volume = data["Volume"].astype(float)
    daily = close.pct_change()
    x = pd.DataFrame(index=data.index)
    x["return_1d"] = daily
    x["return_5d"] = close.pct_change(5)
    x["return_10d"] = close.pct_change(10)
    x["ma_ratio_5"] = close / close.rolling(5).mean() - 1
    x["ma_ratio_20"] = close / close.rolling(20).mean() - 1
    x["volatility_10d"] = daily.rolling(10).std()
    x["volatility_20d"] = daily.rolling(20).std()
    x["volume_change"] = volume.pct_change()
    x["range_pct"] = (data["High"] - data["Low"]) / close
    x["target_next_return"] = daily.shift(-1)
    return x.replace([float("inf"), float("-inf")], float("nan")).dropna()

def chronological_split(frame, test_fraction=0.2):
    if not 0 < test_fraction < 1:
        raise ValueError("test_fraction must be between 0 and 1.")
    split = int(len(frame) * (1 - test_fraction))
    if split <= 0 or split >= len(frame):
        raise ValueError("Not enough rows for requested split.")
    return frame.iloc[:split].copy(), frame.iloc[split:].copy()
