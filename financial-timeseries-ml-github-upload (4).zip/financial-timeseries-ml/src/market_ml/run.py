import json
from pathlib import Path
from src.market_ml.data import download_ohlcv
from src.market_ml.features import FEATURE_COLUMNS, chronological_split, make_features
from src.market_ml.modeling import evaluate_model, simulate_long_only_strategy

def main():
    ticker = "SPY"
    prices = download_ohlcv(ticker=ticker, start="2015-01-01")
    data = make_features(prices)
    train, test = chronological_split(data, test_fraction=0.2)
    model_metrics, predictions = evaluate_model(train, test, FEATURE_COLUMNS)
    strategy_metrics, backtest = simulate_long_only_strategy(predictions)
    metrics = {"ticker": ticker, "train_rows": len(train), **model_metrics, **strategy_metrics}
    reports = Path("reports")
    reports.mkdir(exist_ok=True)
    (reports / "metrics.json").write_text(json.dumps(metrics, indent=2))
    predictions.to_csv(reports / "test_predictions.csv")
    backtest.to_csv(reports / "equity_curve.csv")
    print(json.dumps(metrics, indent=2))

if __name__ == "__main__":
    main()
