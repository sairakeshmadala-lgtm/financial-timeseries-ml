import pandas as pd
import pytest
from src.market_ml.features import chronological_split

def test_split_is_chronological():
    frame = pd.DataFrame({"value": range(100)})
    train, test = chronological_split(frame, .2)
    assert len(train) == 80 and len(test) == 20
    assert train.index.max() < test.index.min()

def test_invalid_fraction_fails():
    with pytest.raises(ValueError):
        chronological_split(pd.DataFrame({"x": range(10)}), 1.0)
