import numpy as np
import pandas as pd
from src.market_ml.features import make_features

def test_features_and_next_day_target():
    idx = pd.date_range("2021-01-01", periods=80, freq="B")
    close = pd.Series(np.linspace(100, 120, 80), index=idx)
    prices = pd.DataFrame({"High": close*1.01, "Low": close*.99,
                           "Close": close, "Volume": 1000.0}, index=idx)
    result = make_features(prices)
    assert "target_next_return" in result.columns
    d = result.index[0]
    expected = close.pct_change().shift(-1).loc[d]
    assert np.isclose(result.loc[d, "target_next_return"], expected)
